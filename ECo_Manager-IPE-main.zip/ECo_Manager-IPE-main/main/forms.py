from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import password_validation
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.validators import UnicodeUsernameValidator

username_validator = UnicodeUsernameValidator()

class RegisterForm(UserCreationForm):
    email = forms.EmailField(label=_('E-mail'), max_length=50,
                             widget=(forms.TextInput(attrs={'class': 'form-control'})))
    password1 = forms.CharField(label=_('Senha'),
                                widget=(forms.PasswordInput(attrs={'class': 'form-control'})))
    password2 = forms.CharField(label=_('Confirme a senha'), widget=forms.PasswordInput(attrs={'class': 'form-control'}),)
    username = forms.CharField(
        label=_('Nome de usuário'),
        max_length=20,
        error_messages={'unique': _("Já existe um usuário com este nome!")},
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2',)