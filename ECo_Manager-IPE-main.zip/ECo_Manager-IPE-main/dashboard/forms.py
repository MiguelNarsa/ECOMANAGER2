from django import forms
from .models import Dado, Profile
from datetime import date
import datetime
from six import string_types
from django.contrib.auth.models import User

class DateInput(forms.DateInput):
    input_type = 'date'

class FormDado(forms.ModelForm):
    consumo_p = forms.TextInput()
    consumo_fp = forms.TextInput()
    energia_ativa = forms.TextInput()
    energia_reativa = forms.TextInput()
    demanda_consumida_p = forms.TextInput()
    demanda_consumida_fp = forms.TextInput()
    demanda_contratada = forms.TextInput()
    energia_gerada = forms.TextInput()

    data_tempo = forms.DateField(widget=DateInput, label='Data')

    class Meta:
        model = Dado
        fields = ['consumo_p', 'consumo_fp', 'energia_ativa', 'energia_reativa', 'demanda_consumida_p', 'demanda_consumida_fp', 'demanda_contratada', 'energia_gerada', 'data_tempo']
        labels = {
            'consumo_p': 'Consumo Ponta (kWh)',
            'consumo_fp': 'Consumo Fora Ponta (kWh)',
            'energia_ativa': 'Energia Ativa (kWh)',
            'energia_reativa': 'Energia Reativa (kVArh)',
            'demanda_consumida_p': 'Demanda Medida Ponta (kW)',
            'demanda_consumida_fp': 'Demanda Medida Fora Ponta (kW)',
            'demanda_contratada': 'Demanda Contratada (kW)',
            'energia_gerada': 'Energia Gerada (kWh)',
            'data_tempo': 'Data',
        }
        widgets = {
            'consumo_p': forms.TextInput(attrs={'class': 'form-control'}),
            'consumo_fp': forms.TextInput(attrs={'class': 'form-control'}),
            'energia_ativa': forms.TextInput(attrs={'class': 'form-control'}),
            'energia_reativa': forms.TextInput(attrs={'class': 'form-control'}),
            'demanda_consumida_p': forms.TextInput(attrs={'class': 'form-control'}),
            'demanda_consumida_fp': forms.TextInput(attrs={'class': 'form-control'}),
            'demanda_contratada': forms.TextInput(attrs={'class': 'form-control'}),
            'energia_gerada': forms.TextInput(attrs={'class': 'form-control'}),
        }

class UpdateUserForm(forms.ModelForm):
    username = forms.CharField(max_length=100,
                               required=True,
                               widget=forms.TextInput(attrs={'class': 'form-control'}),
                               label='Nome de usuário')
    email = forms.EmailField(required=True,
                             widget=forms.TextInput(attrs={'class': 'form-control'}),
                             label='E-mail')

    class Meta:
        model = User
        fields = ['username', 'email']

class UpdateProfileForm(forms.ModelForm):
    concessionaria = forms.TextInput()
    subgrupo = forms.TextInput()
    modalidade_tarifaria = forms.TextInput()
    area = forms.TextInput()
    efetivo = forms.TextInput()
    data_inicio = forms.DateField(widget=DateInput, label='Data de início dos dados')
    data_fim = forms.DateField(widget=DateInput, label='Data de fim dos dados')

    class Meta:
        model = Profile
        fields = ['concessionaria', 'subgrupo', 'modalidade_tarifaria', 'area', 'efetivo', 'data_inicio', 'data_fim']
        labels = {
            'concessionaria': 'Concessionária',
            'modalidade_tarifaria': 'Modalidade Tarifária',
            'area': 'Área (Metros Quadrados)',
            'efetivo': 'Efetivo da OM'
        }
        widgets = {
            'area': forms.TextInput(attrs={'class': 'form-control'}),
            'efetivo': forms.TextInput(attrs={'class': 'form-control'}),
        }