from django.urls import path
from . import views

urlpatterns = [
    path('dashboard', views.dashboard, name='dashboard'),
    path('add-dashboard', views.add_dashboard, name='add_dashboard'),
    path('editar-dados-dashboard', views.editar_dados_dashboard, name='editar_dados_dashboard'),
    path('update-dashboard/<str:pk>/', views.update_dashboard, name='update_dashboard'),
    path('delete-dashboard/<str:pk>/', views.delete_dashboard, name='delete_dashboard'),
    path('demanda-mensal', views.demanda_mensal, name='demanda_mensal'),
    path('consumo-efm', views.consumo_efm, name='consumo_efm'),
    path('energia-fp', views.energia_fp, name='energia_fp'),
]
