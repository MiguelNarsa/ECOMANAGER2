from django.db import models
from django.contrib.auth.models import User
import datetime

# Create your models here.

class Dado(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    consumo_p = models.DecimalField(max_digits=8, decimal_places=2)
    consumo_fp = models.DecimalField(max_digits=8, decimal_places=2)
    energia_ativa = models.DecimalField(max_digits=8, decimal_places=2)
    energia_reativa = models.DecimalField(max_digits=8, decimal_places=2)
    demanda_consumida_p = models.DecimalField(max_digits=8, decimal_places=2)
    demanda_consumida_fp = models.DecimalField(max_digits=8, decimal_places=2)
    demanda_contratada = models.DecimalField(max_digits=8, decimal_places=2)
    energia_gerada = models.DecimalField(max_digits=8, decimal_places=2)

    data_tempo = models.DateField()

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    LIGHT = "LIGHT"
    A2 = "A2"
    A4 = "A4"
    A5 = "A5"
    AZUL = "AZUL"
    VERDE = "VERDE"

    CONCESSIONARIA_CHOICES = [
        (LIGHT, "Light"),
    ]

    SUBGRUPO_CHOICES = [
        (A2, "A2"),
        (A4, "A4"),
        (A5, "A5"),
    ]

    MODALIDADE_CHOICES = [
        (AZUL, "Azul"),
        (VERDE, "Verde")
    ]

    concessionaria = models.CharField(
        max_length=5,
        choices=CONCESSIONARIA_CHOICES,
        default=LIGHT
    )

    subgrupo = models.CharField(
        max_length=2,
        choices=SUBGRUPO_CHOICES,
        default=A2
    )
    
    modalidade_tarifaria = models.CharField(
        max_length=5,
        choices=MODALIDADE_CHOICES,
        default=VERDE
    )

    area = models.PositiveIntegerField(default=1)
    efetivo = models.PositiveIntegerField(default=1)

    data_inicio = models.DateField(default=datetime.date(datetime.date.today().year, 1, 1))
    data_fim = models.DateField(default=datetime.date(datetime.date.today().year, 12, 31))