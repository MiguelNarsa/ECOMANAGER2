from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.core.paginator import Paginator
from dashboard.forms import FormDado, UpdateUserForm, UpdateProfileForm
import datetime
import math

from .models import Dado, Profile

# Create your views here.


@login_required(login_url="/home")
def dashboard(request):
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect('/dashboard')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'dashboard/dashboard.html', {'user_form': user_form, 'profile_form': profile_form})


@login_required(login_url="/home")
def editar_dados_dashboard(request):
    data_list = Dado.objects.filter(user=request.user)
    paginator = Paginator(data_list, 10)
    page = request.GET.get('p')
    data = paginator.get_page(page)
    return render(request, 'dashboard/editar_dados_dashboard.html', {"dados": data})


@login_required(login_url="/home")
def add_dashboard(request):
    if request.method == "POST":
        form = FormDado(request.POST)
        if form.is_valid():
            dado = form.save(commit=False)
            dado.user = request.user
            dado.save()
            return redirect("/add-dashboard")
    else:
        form = FormDado()

    return render(request, 'dashboard/add_dashboard.html', {"form": form})


@login_required(login_url="/home")
def update_dashboard(request, pk):
    data = Dado.objects.get(id=pk)
    form = FormDado(instance=data)
    if request.method == "POST":
        form = FormDado(request.POST, instance=data)
        if form.is_valid():
            form.save()
            return redirect("/editar-dados-dashboard")

    return render(request, 'dashboard/update_dashboard.html', {"form": form})


@login_required(login_url="/home")
def delete_dashboard(request, pk):
    data = Dado.objects.get(id=pk)
    if request.method == "POST":
        data.delete()
        return redirect("/dashboard")
    return render(request, 'dashboard/delete_dashboard.html', {"item": data})


@login_required(login_url="/home")
def demanda_mensal(request):
    try:
        labels = []
        data_demanda_consumida_p = []
        data_demanda_consumida_p_media = []
        data_demanda_consumida_fp = []
        data_demanda_consumida_fp_media = []
        data_demanda_contratada = []

        meses_multa_p = []
        meses_multa_fp = []

        queryset_profile = Profile.objects.filter(user=request.user)
        for perfil in queryset_profile:
            data_inicio = perfil.data_inicio
            data_fim = perfil.data_fim
        queryset = Dado.objects.filter(user=request.user, data_tempo__gte=data_inicio, data_tempo__lte=data_fim)

        for dado in queryset:
            labels.append(str(dado.data_tempo))
            data_demanda_consumida_p.append(dado.demanda_consumida_p)
            data_demanda_consumida_fp.append(dado.demanda_consumida_fp)
            data_demanda_contratada.append(dado.demanda_contratada)

            if dado.demanda_contratada < dado.demanda_consumida_p:
                meses_multa_p.append(str(dado.data_tempo)[5:7] + "/" + str(dado.data_tempo)[2:4])

            if dado.demanda_contratada < dado.demanda_consumida_fp:
                meses_multa_fp.append(str(dado.data_tempo)[5:7] + "/" + str(dado.data_tempo)[2:4]) 

        meses_multa_p_string = ', '.join(map(str, meses_multa_p))
        meses_multa_fp_string = ', '.join(map(str, meses_multa_fp))

        demanda_consumida_p_media_valor = sum(
            data_demanda_consumida_p)/len(data_demanda_consumida_p)
        demanda_consumida_fp_media_valor = sum(
            data_demanda_consumida_fp)/len(data_demanda_consumida_fp)

        for i in range(len(data_demanda_consumida_p)):
            data_demanda_consumida_p_media.append(demanda_consumida_p_media_valor)
            data_demanda_consumida_fp_media.append(
                demanda_consumida_fp_media_valor)

        zipped_list_demanda_consumida_p = sorted(list(zip(
            labels, data_demanda_consumida_p)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_demanda_consumida_p_media = sorted(list(zip(
            labels, data_demanda_consumida_p_media)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_demanda_consumida_fp = sorted(list(zip(
            labels, data_demanda_consumida_fp)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_demanda_consumida_fp_media = sorted(list(zip(
            labels, data_demanda_consumida_fp_media)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_demanda_contratada = sorted(list(zip(
            labels, data_demanda_contratada)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))

        labels = list(list(zip(*zipped_list_demanda_consumida_p))[0])
        data_demanda_consumida_p = list(
            list(zip(*zipped_list_demanda_consumida_p))[1])
        data_demanda_consumida_p_media = list(
            list(zip(*zipped_list_demanda_consumida_p_media))[1])
        data_demanda_consumida_fp = list(
            list(zip(*zipped_list_demanda_consumida_fp))[1])
        data_demanda_consumida_fp_media = list(
            list(zip(*zipped_list_demanda_consumida_fp_media))[1])
        data_demanda_contratada = list(
            list(zip(*zipped_list_demanda_contratada))[1])

        for i in range(len(labels)):
            labels[i] = labels[i][5:7] + "/" + labels[i][0:4]

        data_demanda_consumida_p = [float(i) for i in data_demanda_consumida_p]
        data_demanda_consumida_p_media = [float(i) for i in data_demanda_consumida_p_media]
        data_demanda_consumida_fp = [float(i) for i in data_demanda_consumida_fp]
        data_demanda_consumida_fp_media = [float(i) for i in data_demanda_consumida_fp_media]
        data_demanda_contratada = [float(i) for i in data_demanda_contratada]

    except:
        pass

    return render(request, 'dashboard/demanda_mensal.html', {'labels': labels, 'data_demanda_consumida_p': data_demanda_consumida_p, 'data_demanda_consumida_p_media': data_demanda_consumida_p_media, 'data_demanda_consumida_fp': data_demanda_consumida_fp, 'data_demanda_consumida_fp_media': data_demanda_consumida_fp_media, 'data_demanda_contratada': data_demanda_contratada, 'meses_multa_p': meses_multa_p_string, 'meses_multa_fp': meses_multa_fp_string})

@login_required(login_url="/home")
def consumo_efm(request):
    try:
        labels = []
        data_consumo_efetivo = []
        data_consumo_m2 = []

        queryset_profile = Profile.objects.filter(user=request.user)

        for perfil in queryset_profile:
            area = perfil.area
            efetivo = perfil.efetivo
            data_inicio = perfil.data_inicio
            data_fim = perfil.data_fim

        queryset = Dado.objects.filter(user=request.user, data_tempo__gte=data_inicio, data_tempo__lte=data_fim)

        for dado in queryset:
            labels.append(str(dado.data_tempo))
            print(dado.data_tempo > data_fim)
            data_consumo_efetivo.append((dado.consumo_p + dado.consumo_fp)/efetivo)
            data_consumo_m2.append((dado.consumo_p + dado.consumo_fp)/area)

        zipped_list_consumo_efetivo = sorted(list(zip(
            labels, data_consumo_efetivo)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_consumo_m2 = sorted(list(zip(
            labels, data_consumo_m2)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))

        labels = list(list(zip(*zipped_list_consumo_efetivo))[0])
        data_consumo_efetivo = list(
            list(zip(*zipped_list_consumo_efetivo))[1])
        data_consumo_m2 = list(
            list(zip(*zipped_list_consumo_m2))[1])

        data_consumo_efetivo = [float(i) for i in data_consumo_efetivo]
        data_consumo_m2 = [float(i) for i in data_consumo_m2]

        for i in range(len(labels)):
            labels[i] = labels[i][5:7] + "/" + labels[i][0:4]

    except:
        pass

    return render(request, 'dashboard/consumo_efm.html', {'labels': labels, 'data_consumo_efetivo': data_consumo_efetivo, 'data_consumo_m2': data_consumo_m2})

@login_required(login_url="/home")
def energia_fp(request):
    try:
        labels = []
        data_energia_ativa = []
        data_energia_reativa = []
        data_fatorpot = []
        data_fracger = []

        resp_fracger_final = 0

        queryset_profile = Profile.objects.filter(user=request.user)
        for perfil in queryset_profile:
            data_inicio = perfil.data_inicio
            data_fim = perfil.data_fim
        queryset = Dado.objects.filter(user=request.user, data_tempo__gte=data_inicio, data_tempo__lte=data_fim)

        for dado in queryset:
            labels.append(str(dado.data_tempo))
            data_energia_ativa.append(dado.energia_ativa)
            data_energia_reativa.append(dado.energia_reativa)
            data_fatorpot.append(float(dado.energia_ativa)/math.sqrt(dado.energia_ativa**2 + dado.energia_reativa**2))
            data_fracger.append(dado.energia_gerada/(dado.consumo_p + dado.consumo_fp))

        zipped_list_consumo_efetivo = sorted(list(zip(
            labels, data_energia_ativa)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_consumo_m2 = sorted(list(zip(
            labels, data_energia_reativa)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_fatorpot = sorted(list(zip(
            labels, data_fatorpot)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))
        zipped_list_fracger = sorted(list(zip(
            labels, data_fracger)), key=lambda x: datetime.datetime.strptime(x[0], '%Y-%m-%d'))

        labels = list(list(zip(*zipped_list_consumo_efetivo))[0])
        data_energia_ativa = list(
            list(zip(*zipped_list_consumo_efetivo))[1])
        data_energia_reativa = list(
            list(zip(*zipped_list_consumo_m2))[1])
        data_fatorpot = list(
            list(zip(*zipped_list_fatorpot))[1])
        data_fracger = list(
            list(zip(*zipped_list_fracger))[1])

        data_energia_ativa = [float(i) for i in data_energia_ativa]
        data_energia_reativa = [float(i) for i in data_energia_reativa]
        data_fatorpot = [float(i) for i in data_fatorpot]
        data_fracger = [float(i) for i in data_fracger]

        for i in range(len(labels)):
            labels[i] = labels[i][5:7] + "/" + labels[i][0:4]

        resp_fracger_final = round(float(sum(data_fracger)/len(data_fracger)) * 100, 2)

        print(resp_fracger_final)
    
    except:
        pass

    return render(request, 'dashboard/energia_fp.html', {'labels': labels, 'data_energia_ativa': data_energia_ativa, 'data_energia_reativa': data_energia_reativa, 'data_fatorpot': data_fatorpot, 'data_fracger': data_fracger, 'resp_fracger_final': resp_fracger_final})
