from django.contrib import admin
from .models import Dado, Profile

# Register your models here.

class dadoAdmin(admin.ModelAdmin):
    list_display = ('user', 'data_tempo', 'demanda_contratada')

admin.site.register(Dado, dadoAdmin)
admin.site.register(Profile)